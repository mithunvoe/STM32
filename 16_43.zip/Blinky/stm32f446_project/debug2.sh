# In separate terminal:
gdb-multiarch target/thumbv7em-none-eabihf/debug/stm32f446_project
